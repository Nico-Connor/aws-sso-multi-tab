# Multi-Account Containers Localization

![Linter status](https://github.com/mozilla-l10n/multi-account-containers-l10n/workflows/L10n%20Linter/badge.svg)

Localization for the Firefox Multi-Account Containers add-on

The application code with build instructions can be found
at <https://github.com/mozilla/multi-account-containers>.

Contributions can happen from [Pontoon](https://pontoon.mozilla.org/projects/firefox-multi-account-containers/).

# License

Translations in this repository are available under the
terms of the [Mozilla Public License v2.0](https://www.mozilla.org/MPL/2.0/).
